function folder = getRootFolder()
    folder = fileparts(mfilename('fullpath'));
end