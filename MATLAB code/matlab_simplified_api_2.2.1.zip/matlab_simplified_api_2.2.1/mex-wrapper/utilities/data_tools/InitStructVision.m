function structVision = InitStructVision(datatype_Vision)
    structVision = Simulink.Bus.createMATLABStruct(datatype_Vision);
end