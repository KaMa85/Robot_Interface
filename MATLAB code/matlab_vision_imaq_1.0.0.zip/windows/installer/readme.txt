Kinova Vision Module MATLAB Image Acquisition Toolbox Adaptor Installer

1. INTRODUCTION
This application, kinova_vision_imaq_<version>.exe, installs the following components:
- The Kinova Vision Module MATLAB Image Acquisition Toolbox Adaptor library (i.e. the product)
- [Optionally] The required GStreamer libraries (see note below)
- [Optionally] The Windows redistribution libraries installer (runs automatically)

Note: If GStreamer version 1.15.2 or more recent is already installed on your system, you don't
need to install the GStreamer libraries component.

The <version> field indicates the version of the product.


2. REQUIREMENTS
You need to have administration privileges to run this installer.
This is required to update the Windows registry, as well as optionally update environment variables.

This installer can only be run on a Windows 64-bit machine.


3. SYSTEM MODIFICATIONS
3.1 Windows Registry
The installation information is stored in the Windows registry for the local machine (HKLM).
This makes the application visible in the "Program and Feature" control panel, allowing you to 
uninstall the application if required.

3.2 Environment Variables
If the GStreamer libraries component is installed, the following environment variables are affected.
- User environment: GST_PLUGIN_SYSTEM_PATH (added if not already existing)
- System environment: Path

For both variables, the path to the installed GStreamer libraries is added. Upon uninstalling the
application, that path is removed from these environment variables.
