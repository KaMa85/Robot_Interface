classdef enumToolMode < int32
    enumeration
        toolMode_force (1)
        toolMode_speed (2)
        toolMode_reach (3)
    end
end
